# CS 340 Grazioso Salvare Dashboard

This folder contains the public-safe original source and the enhanced source for the Databases artifact.

- `original/` contains the original dashboard and CRUD module. Hard-coded credential values are redacted for public publication.
- `enhanced/` contains the secured CRUD module, enhanced dashboard, test file, `.env.example`, requirements, and project documentation.
- `narrative/` contains the submitted enhancement narrative in Word and PDF formats.
