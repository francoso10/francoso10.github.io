"""
animal_shelter.py
Author: Francisco Sousa
Course: CS 499 Computer Science Capstone
Artifact: CS 340 Grazioso Salvare Dashboard
Enhancement Category: Databases
Version: 2.0
Date: June 2026

Enhancement Summary:
This enhanced CRUD module removes hardcoded MongoDB credentials, adds
role-based operation checks, validates and sanitizes MongoDB filters to reduce
NoSQL injection risk, and provides index creation for common dashboard queries.
These changes support secure database access, least privilege, and faster
retrieval for the Grazioso Salvare rescue-animal dashboard.
"""

from __future__ import annotations

import copy
import logging
import os
from typing import Any, Dict, Iterable, List, Optional
from urllib.parse import quote_plus

from pymongo import ASCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the AAC animal collection in MongoDB.

    Security enhancements:
    - Credentials are read from environment variables or constructor arguments.
    - Dashboard access defaults to a read-only application role.
    - Query filters are recursively validated against an allowlist of safe
      MongoDB operators.
    - Write/delete/index operations require elevated application roles.
    """

    # Operators required by the dashboard's approved filter options.
    ALLOWED_FILTER_OPERATORS = {"$and", "$or", "$in", "$gte", "$lte", "$eq"}
    ALLOWED_UPDATE_OPERATORS = {"$set"}

    # Simple application-level RBAC. In production this should be paired with
    # MongoDB database users configured with matching least-privilege roles.
    ROLE_PERMISSIONS = {
        "read": {"read"},
        "editor": {"read", "create", "update"},
        "admin": {"read", "create", "update", "delete", "index"},
    }

    def __init__(
        self,
        username: Optional[str] = None,
        password: Optional[str] = None,
        *,
        role: Optional[str] = None,
        host: Optional[str] = None,
        port: Optional[int] = None,
        db_name: Optional[str] = None,
        collection_name: Optional[str] = None,
        auth_source: Optional[str] = None,
        create_indexes: bool = False,
    ) -> None:
        """Create a secure MongoDB connection.

        Environment variables supported:
        MONGO_USER, MONGO_PASS, MONGO_HOST, MONGO_PORT, MONGO_DB,
        MONGO_COLLECTION, MONGO_AUTH_SOURCE, MONGO_APP_ROLE.
        """
        self.logger = logging.getLogger(self.__class__.__name__)
        if not logging.getLogger().handlers:
            logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")

        self.role = (role or os.getenv("MONGO_APP_ROLE", "read")).lower().strip()
        if self.role not in self.ROLE_PERMISSIONS:
            raise ValueError(f"Unsupported application role: {self.role}")

        self.username = username or os.getenv("MONGO_USER")
        self.password = password or os.getenv("MONGO_PASS")
        self.host = host or os.getenv("MONGO_HOST", "localhost")
        self.port = int(port or os.getenv("MONGO_PORT", "27017"))
        self.db_name = db_name or os.getenv("MONGO_DB", "aac")
        self.collection_name = collection_name or os.getenv("MONGO_COLLECTION", "animals")
        self.auth_source = auth_source or os.getenv("MONGO_AUTH_SOURCE", "admin")

        if not self.username or not self.password:
            raise ValueError(
                "MongoDB credentials are not configured. Set MONGO_USER and "
                "MONGO_PASS environment variables or pass credentials to AnimalShelter."
            )

        user = quote_plus(self.username)
        pwd = quote_plus(self.password)
        uri = f"mongodb://{user}:{pwd}@{self.host}:{self.port}/?authSource={self.auth_source}"

        self.client: MongoClient = MongoClient(uri, serverSelectionTimeoutMS=5000)
        self.database: Database = self.client[self.db_name]
        self.collection: Collection = self.database[self.collection_name]

        if create_indexes:
            self.ensure_indexes()

    def _require_permission(self, permission: str) -> None:
        if permission not in self.ROLE_PERMISSIONS[self.role]:
            raise PermissionError(
                f"Role '{self.role}' does not have permission for '{permission}' operations."
            )

    @staticmethod
    def _validate_key(key: Any, allowed_operators: Iterable[str]) -> str:
        if not isinstance(key, str) or not key:
            raise ValueError("MongoDB keys must be non-empty strings.")

        # MongoDB operators are allowed only when explicitly whitelisted.
        if key.startswith("$") and key not in allowed_operators:
            raise ValueError(f"Disallowed MongoDB operator: {key}")

        # Field names should not contain special characters that can alter query paths.
        if not key.startswith("$") and ("$" in key or "." in key or "\x00" in key):
            raise ValueError(f"Unsafe MongoDB field name: {key}")

        return key

    @classmethod
    def _sanitize_value(cls, value: Any, allowed_operators: Iterable[str]) -> Any:
        if isinstance(value, dict):
            return cls._sanitize_document(value, allowed_operators)
        if isinstance(value, list):
            return [cls._sanitize_value(item, allowed_operators) for item in value]
        return value

    @classmethod
    def _sanitize_document(cls, document: Dict[str, Any], allowed_operators: Iterable[str]) -> Dict[str, Any]:
        if not isinstance(document, dict):
            raise ValueError("MongoDB query and document inputs must be dictionaries.")

        sanitized: Dict[str, Any] = {}
        for key, value in document.items():
            safe_key = cls._validate_key(key, allowed_operators)
            sanitized[safe_key] = cls._sanitize_value(value, allowed_operators)
        return sanitized

    @classmethod
    def sanitize_filter(cls, query: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Return a sanitized copy of an approved MongoDB filter."""
        if query is None:
            return {}
        return cls._sanitize_document(copy.deepcopy(query), cls.ALLOWED_FILTER_OPERATORS)

    @classmethod
    def sanitize_insert_document(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize an insert document by disallowing query/update operators."""
        return cls._sanitize_document(copy.deepcopy(data), allowed_operators=set())

    @classmethod
    def sanitize_update_document(cls, update_data: Dict[str, Any]) -> Dict[str, Any]:
        """Sanitize update instructions; only the $set update operator is allowed."""
        sanitized = cls._sanitize_document(copy.deepcopy(update_data), cls.ALLOWED_UPDATE_OPERATORS)
        if not sanitized or any(operator not in cls.ALLOWED_UPDATE_OPERATORS for operator in sanitized):
            raise ValueError("Only explicit $set updates are allowed.")
        return sanitized

    def ensure_indexes(self) -> List[str]:
        """Create indexes that support common dashboard filters and sorting.

        Returns a list of index names created or confirmed by MongoDB.
        """
        self._require_permission("index")
        try:
            index_names = [
                self.collection.create_index([("breed", ASCENDING)], name="idx_breed"),
                self.collection.create_index([("animal_type", ASCENDING)], name="idx_animal_type"),
                self.collection.create_index([("sex_upon_outcome", ASCENDING)], name="idx_sex_outcome"),
                self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)], name="idx_age_weeks"),
                self.collection.create_index(
                    [
                        ("animal_type", ASCENDING),
                        ("breed", ASCENDING),
                        ("sex_upon_outcome", ASCENDING),
                        ("age_upon_outcome_in_weeks", ASCENDING),
                    ],
                    name="idx_rescue_filters",
                ),
            ]
            self.logger.info("Database indexes verified: %s", ", ".join(index_names))
            return index_names
        except PyMongoError as exc:
            self.logger.error("Unable to create indexes: %s", exc)
            return []

    def create(self, data: Dict[str, Any]) -> bool:
        """Insert an animal document if the active role allows writes."""
        self._require_permission("create")
        if not data:
            return False
        try:
            sanitized_data = self.sanitize_insert_document(data)
            result = self.collection.insert_one(sanitized_data)
            return result.acknowledged
        except (PyMongoError, ValueError) as exc:
            self.logger.error("Create operation failed: %s", exc)
            return False

    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: int = 0,
    ) -> List[Dict[str, Any]]:
        """Read animal documents using a sanitized filter.

        The dashboard uses this method for all filtered views. Empty or None queries
        return all documents available to the database user.
        """
        self._require_permission("read")
        try:
            safe_query = self.sanitize_filter(query)
            cursor = self.collection.find(safe_query, projection)
            if limit and limit > 0:
                cursor = cursor.limit(limit)
            return list(cursor)
        except (PyMongoError, ValueError) as exc:
            self.logger.error("Read operation failed: %s", exc)
            return []

    def update(self, query: Dict[str, Any], update_data: Dict[str, Any]) -> int:
        """Update documents using sanitized filters and explicit $set updates."""
        self._require_permission("update")
        try:
            safe_query = self.sanitize_filter(query)
            safe_update = self.sanitize_update_document(update_data)
            result = self.collection.update_many(safe_query, safe_update)
            return result.modified_count
        except (PyMongoError, ValueError) as exc:
            self.logger.error("Update operation failed: %s", exc)
            return 0

    def delete(self, query: Dict[str, Any]) -> int:
        """Delete matching documents only when the active role allows deletion."""
        self._require_permission("delete")
        try:
            safe_query = self.sanitize_filter(query)
            if not safe_query:
                raise ValueError("Refusing to delete all documents without an explicit filter.")
            result = self.collection.delete_many(safe_query)
            return result.deleted_count
        except (PyMongoError, ValueError) as exc:
            self.logger.error("Delete operation failed: %s", exc)
            return 0
