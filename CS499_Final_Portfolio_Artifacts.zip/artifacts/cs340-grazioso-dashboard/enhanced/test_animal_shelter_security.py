"""
Lightweight tests for the CS 499 database enhancement.
These tests focus on sanitizer and role behavior and do not require a live MongoDB
connection. They are skipped automatically if PyMongo is unavailable.
"""

import pytest

pytest.importorskip("pymongo")
from animal_shelter import AnimalShelter


def test_sanitize_filter_accepts_dashboard_query():
    query = {"$and": [
        {"animal_type": "Dog"},
        {"breed": {"$in": ["Newfoundland"]}},
        {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
    ]}
    assert AnimalShelter.sanitize_filter(query) == query


def test_sanitize_filter_rejects_where_operator():
    with pytest.raises(ValueError):
        AnimalShelter.sanitize_filter({"$where": "this.age > 1"})


def test_sanitize_filter_rejects_unsafe_field_name():
    with pytest.raises(ValueError):
        AnimalShelter.sanitize_filter({"profile.name": "unsafe"})


def test_read_role_does_not_have_delete_permission():
    permissions = AnimalShelter.ROLE_PERMISSIONS["read"]
    assert "read" in permissions
    assert "delete" not in permissions
