"""
ProjectTwoDashboard_enhanced.py
Author: Francisco Sousa
Course: CS 499 Computer Science Capstone
Artifact: CS 340 Grazioso Salvare Dashboard
Enhancement Category: Databases
Version: 2.0
Date: June 2026

This enhanced dashboard removes hardcoded credentials and connects to the
AnimalShelter CRUD module using environment-based configuration. MongoDB query
filters are constructed only from approved dashboard options and are sanitized in
animal_shelter.py before database execution.
"""

# Setup the Jupyter version of Dash
from jupyter_dash import JupyterDash

# Configure dashboard components
import base64
import os

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import dash_table, dcc, html
from dash.dependencies import Input, Output

from animal_shelter import AnimalShelter

JupyterDash.infer_jupyter_proxy_config()

# ---------------------------------------------------------------------------
# Data Manipulation / Model
# ---------------------------------------------------------------------------
# Required environment variables before running the dashboard:
#   MONGO_USER=<database username>
#   MONGO_PASS=<database password>
# Optional environment variables:
#   MONGO_HOST=localhost
#   MONGO_PORT=27017
#   MONGO_DB=aac
#   MONGO_COLLECTION=animals
#   MONGO_AUTH_SOURCE=admin
#   MONGO_APP_ROLE=read

DASHBOARD_COLUMNS = [
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
    "location_lat",
    "location_long",
]

try:
    # The dashboard uses the read-only application role because users only need
    # to view and filter animal data. Write and admin functions are restricted
    # in the CRUD module.
    db = AnimalShelter(role="read")
    connection_error = None
except Exception as exc:
    db = None
    connection_error = str(exc)


def load_data(query=None):
    """Load animal data safely through the enhanced CRUD module."""
    if db is None:
        return pd.DataFrame(columns=DASHBOARD_COLUMNS)

    records = db.read(query or {})
    dff = pd.DataFrame.from_records(records)

    # ObjectId values do not serialize cleanly into Dash DataTable records.
    if "_id" in dff.columns:
        dff.drop(columns=["_id"], inplace=True)

    return dff


df = load_data({})

# ---------------------------------------------------------------------------
# Dashboard Layout / View
# ---------------------------------------------------------------------------
app = JupyterDash(__name__)

# The original project file included "Grazioso Salvare Logo (1).png". This
# fallback supports either filename so the notebook can run in different folders.
logo_candidates = ["Grazioso Salvare Logo (1).png", "Grazioso Salvare Logo.png"]
logo_path = next((path for path in logo_candidates if os.path.exists(path)), None)
encoded_logo = ""
if logo_path:
    with open(logo_path, "rb") as image_file:
        encoded_logo = base64.b64encode(image_file.read()).decode()

status_message = "Connected using read-only dashboard role."
if connection_error:
    status_message = f"Database connection not available: {connection_error}"

app.layout = html.Div([
    html.Center(html.A(
        html.Img(src=f"data:image/png;base64,{encoded_logo}", style={"height": "120px"}) if encoded_logo else html.Div(),
        href="https://www.snhu.edu",
        target="_blank",
    )),
    html.Center(html.B(html.H1("CS-340 Dashboard - Francisco Sousa"))),
    html.Center(html.P(status_message)),
    html.Hr(),
    html.Div(
        dcc.RadioItems(
            id="filter-type",
            options=[
                {"label": "Water Rescue", "value": "water"},
                {"label": "Mountain/Wilderness", "value": "mountain"},
                {"label": "Disaster/Tracking", "value": "disaster"},
                {"label": "Reset", "value": "reset"},
            ],
            value="reset",
            labelStyle={"display": "inline-block", "margin-right": "18px"},
        )
    ),
    html.Hr(),
    dash_table.DataTable(
        id="datatable-id",
        columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
        data=df.to_dict("records"),
        page_size=12,
        filter_action="native",
        sort_action="native",
        sort_mode="multi",
        row_selectable="single",
        selected_rows=[0] if not df.empty else [],
        style_table={"overflowX": "auto"},
        style_cell={
            "textAlign": "left",
            "minWidth": "120px",
            "width": "120px",
            "maxWidth": "240px",
            "whiteSpace": "normal",
        },
    ),
    html.Br(),
    html.Hr(),
    html.Div(
        className="row",
        style={"display": "flex"},
        children=[
            html.Div(id="graph-id", className="col s12 m6"),
            html.Div(id="map-id", className="col s12 m6"),
        ],
    ),
])

# ---------------------------------------------------------------------------
# Interaction Between Components / Controller
# ---------------------------------------------------------------------------

def build_query(filter_type):
    """Build approved MongoDB filters for the rescue-training categories."""
    if filter_type == "water":
        return {"$and": [
            {"animal_type": "Dog"},
            {"breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever", "Newfoundland"]}},
            {"sex_upon_outcome": "Intact Female"},
            {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
        ]}
    if filter_type == "mountain":
        return {"$and": [
            {"animal_type": "Dog"},
            {"breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]}},
            {"sex_upon_outcome": "Intact Male"},
            {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}},
        ]}
    if filter_type == "disaster":
        return {"$and": [
            {"animal_type": "Dog"},
            {"breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]}},
            {"sex_upon_outcome": "Intact Male"},
            {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}},
        ]}
    return {}


@app.callback(Output("datatable-id", "data"), [Input("filter-type", "value")])
def update_dashboard(filter_type):
    query = build_query(filter_type)
    dff = load_data(query)
    return dff.to_dict("records")


@app.callback(Output("graph-id", "children"), [Input("datatable-id", "derived_virtual_data")])
def update_graphs(viewData):
    dff = pd.DataFrame(viewData) if viewData else pd.DataFrame()
    if dff.empty or "breed" not in dff.columns:
        return [html.P("No breed data available for the selected filter.")]

    counts = dff["breed"].value_counts().reset_index()
    counts.columns = ["breed", "count"]
    fig = px.pie(counts, names="breed", values="count", title="Breed Distribution in Current Filter")
    return [dcc.Graph(figure=fig)]


@app.callback(
    Output("datatable-id", "style_data_conditional"),
    [Input("datatable-id", "selected_columns")],
)
def update_styles(selected_columns):
    selected_columns = selected_columns or []
    return [{"if": {"column_id": i}, "background_color": "#D2F3FF"} for i in selected_columns]


@app.callback(
    Output("map-id", "children"),
    [Input("datatable-id", "derived_virtual_data"), Input("datatable-id", "derived_virtual_selected_rows")],
)
def update_map(viewData, index):
    if not viewData:
        return [html.P("No location data available.")]

    dff = pd.DataFrame.from_dict(viewData)
    if dff.empty or "location_lat" not in dff.columns or "location_long" not in dff.columns:
        return [html.P("Location columns are unavailable.")]

    row = index[0] if index else 0
    if row >= len(dff):
        row = 0

    lat = dff.iloc[row].get("location_lat")
    lon = dff.iloc[row].get("location_long")
    if pd.isna(lat) or pd.isna(lon):
        return [html.P("Selected animal does not have valid coordinates.")]

    breed = dff.iloc[row].get("breed", "Unknown breed")
    name = dff.iloc[row].get("name", "Unknown")

    return [
        dl.Map(
            style={"width": "1000px", "height": "500px"},
            center=[30.75, -97.48],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(position=[lat, lon], children=[
                    dl.Tooltip(str(breed)),
                    dl.Popup([html.H1("Animal Name"), html.P(str(name))]),
                ]),
            ],
        )
    ]


# Run app and display result in JupyterLab mode.
app.run_server()
