# CS 499 Milestone Four - Database Enhancement

Artifact: CS 340 Grazioso Salvare Dashboard  
Author: Francisco Sousa  
Enhancement Category: Databases

## Enhanced Files

- `animal_shelter.py` - Enhanced MongoDB CRUD module with environment-based credentials, role-based access checks, recursive NoSQL query sanitization, and index creation.
- `ProjectTwoDashboard.ipynb` - Enhanced JupyterDash dashboard using read-only database access and no hardcoded credentials.
- `ProjectTwoDashboard_enhanced.py` - Script version of the enhanced dashboard for easier code review.
- `.env.example` - Safe environment variable template with no real secrets.
- `test_animal_shelter_security.py` - Lightweight tests for sanitizer and role behavior that do not require a live MongoDB connection.

## Required Runtime Configuration

Set the following environment variables before running the dashboard:

```bash
export MONGO_USER="your_username_here"
export MONGO_PASS="your_password_here"
export MONGO_HOST="localhost"
export MONGO_PORT="27017"
export MONGO_DB="aac"
export MONGO_COLLECTION="animals"
export MONGO_AUTH_SOURCE="admin"
export MONGO_APP_ROLE="read"
```

## Enhancement Summary

The original CS 340 project connected to MongoDB using hardcoded credentials and passed dashboard-generated filters directly into the database read method. The enhanced version removes plaintext credentials, centralizes database access through a hardened CRUD module, validates supported MongoDB operators, applies application-level role permissions, and adds index support for the dashboard's rescue filters.
