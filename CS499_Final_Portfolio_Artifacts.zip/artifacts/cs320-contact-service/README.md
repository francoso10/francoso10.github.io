# CS 320 Contact Service

This folder contains the original and enhanced source files and tests for the Algorithms and Data Structures artifact.

- `original/` contains the original Contact Service source and tests.
- `enhanced/` contains the dual-index implementation, updated tests, and `ContactNotFoundException`.
- `narrative/` contains the submitted enhancement narrative in Word and PDF formats.
