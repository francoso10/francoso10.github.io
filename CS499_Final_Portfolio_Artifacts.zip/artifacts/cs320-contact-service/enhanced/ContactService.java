package contactservice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * ContactService.java
 * ===================
 * Service layer that manages a collection of Contact records.
 * Provides O(1) primary lookup by contactId and O(log n) sorted access
 * by last-name prefix using a dual-index data structure.
 *
 * AUTHOR:   Francisco Sousa
 * Course:   CS 499 – Computer Science Capstone, SNHU
 * Created:  2026-05-26
 * Origin:   CS 320 – Software Test, Automation and QA
 *
 * ── CS 499 Enhancement Summary (Category Two – Algorithms and Data Structures) ──
 *
 * 1. DUAL-INDEX ARCHITECTURE                            (Course Outcome 3)
 *    Original: single HashMap<String, Contact> – O(1) ID lookup only.
 *    Enhanced: HashMap (primary) + TreeMap<String, List<String>> (secondary).
 *
 *    primaryIndex   : HashMap<contactId  → Contact>
 *      Time complexity  : O(1) average for get, put, remove
 *      Space complexity : O(n)
 *
 *    secondaryIndex : TreeMap<lastName → List<contactId>>
 *      Time complexity  : O(log n) for get, put, remove (red-black BST)
 *      Space complexity : O(n) — stores IDs only, not Contact objects
 *
 *    The TreeMap is backed by a red-black balanced BST, which guarantees
 *    O(log n) worst-case for all navigational operations (floorKey,
 *    ceilingKey, subMap).  This enables prefix-based name search
 *    (searchByLastName) that the original flat HashMap could not support
 *    without a full O(n) linear scan.
 *
 * 2. CONSOLIDATED UPDATE METHOD                         (Course Outcome 3)
 *    Original: four separate update methods (updateFirstName, updateLastName,
 *    updatePhone, updateAddress) — violates DRY, forces callers to make
 *    multiple round-trips to update more than one field.
 *    Enhanced: single updateContact(id, firstName, lastName, phone, address)
 *    that applies all non-null, non-empty arguments atomically.  Passing null
 *    for a field means "leave this field unchanged."
 *    The secondary index is kept consistent: if lastName changes, the old
 *    entry is removed from the TreeMap and a new one is inserted.
 *
 * 3. CUSTOM EXCEPTION                                   (Course Outcome 3, 5)
 *    Original: generic IllegalArgumentException for both validation failures
 *    and lookup failures — callers cannot distinguish the two cases without
 *    string-matching the exception message.
 *    Enhanced: ContactNotFoundException (extends RuntimeException) is thrown
 *    for all "record not found" cases.  IllegalArgumentException is still
 *    thrown for constraint violations (null/length checks), preserving the
 *    semantic distinction between bad input and missing data.
 *
 * 4. SECONDARY INDEX SEARCH                             (Course Outcome 3)
 *    searchByLastName(prefix) uses TreeMap.subMap() to return all contacts
 *    whose last name starts with the given prefix, in alphabetical order.
 *    Time complexity: O(log n + k) where k = number of matching contacts.
 *    This is asymptotically superior to the O(n) linear scan that would be
 *    required against the HashMap alone.
 *
 * 5. INPUT SANITISATION                                 (Course Outcome 5)
 *    All public methods that accept String parameters trim whitespace before
 *    validation.  A contactId of "  CR7  " is treated as "CR7", preventing
 *    duplicate-key collisions caused by incidental whitespace — a subtle
 *    injection-adjacent correctness issue in the original code.
 */
public class ContactService {

    // ── Primary index ──────────────────────────────────────────────────────
    // HashMap: O(1) average-case for containsKey, get, put, remove.
    // Used for all ID-based operations (the most common access pattern).
    private final Map<String, Contact> primaryIndex = new HashMap<>();

    // ── Secondary index ────────────────────────────────────────────────────
    // TreeMap: O(log n) for all navigational operations.
    // Maps lastName (lower-cased for case-insensitive search) to a list of
    // contactIds that share that last name.  Storing only IDs (not Contact
    // objects) keeps memory overhead minimal and avoids stale-reference bugs.
    //
    // Design note: a List<String> per key handles the case where two contacts
    // share a last name (e.g., two "Smith" entries).
    private final TreeMap<String, List<String>> secondaryIndex = new TreeMap<>();

    // ══════════════════════════════════════════════════════════════════════
    //  WRITE OPERATIONS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Adds a new contact to both indexes.
     *
     * Time complexity: O(log n) — dominated by the TreeMap insertion.
     *   Primary put   : O(1) average
     *   Secondary put : O(log n) for TreeMap.get + TreeMap.put (BST traversal)
     *
     * @param contact the Contact to add (must not be null)
     * @throws IllegalArgumentException   if contact is null
     * @throws IllegalArgumentException   if the contactId already exists
     */
    public void addContact(Contact contact) {
        if (contact == null)
            throw new IllegalArgumentException("Contact must not be null.");

        // Sanitise the ID to prevent whitespace-padded duplicates.
        String id = contact.getContactId().trim();

        if (primaryIndex.containsKey(id))
            throw new IllegalArgumentException(
                "Contact ID already exists: " + id);

        // Insert into primary index – O(1).
        primaryIndex.put(id, contact);

        // Insert into secondary index – O(log n).
        // Key is lower-cased to make name searches case-insensitive.
        String nameKey = contact.getLastName().toLowerCase();
        secondaryIndex.computeIfAbsent(nameKey, k -> new ArrayList<>()).add(id);
    }

    /**
     * Removes a contact from both indexes.
     *
     * Time complexity: O(log n) — dominated by secondary index removal.
     *   Primary remove   : O(1) average
     *   Secondary remove : O(log n) TreeMap.get + O(k) list scan where
     *                      k = contacts sharing the same last name (typically 1)
     *
     * @param contactId the ID of the contact to remove
     * @throws IllegalArgumentException   if contactId is null or blank
     * @throws ContactNotFoundException   if no contact with this ID exists
     */
    public void deleteContact(String contactId) {
        String id = validateId(contactId);

        Contact contact = requireContact(id);

        // Remove from primary index – O(1).
        primaryIndex.remove(id);

        // Remove from secondary index – O(log n) + O(k).
        String nameKey = contact.getLastName().toLowerCase();
        List<String> ids = secondaryIndex.get(nameKey);
        if (ids != null) {
            ids.remove(id);
            // Clean up the TreeMap entry if no IDs remain under this name.
            if (ids.isEmpty())
                secondaryIndex.remove(nameKey);
        }
    }

    /**
     * Updates one or more fields of an existing contact atomically.
     * Pass null for any field you do not wish to change.
     *
     * Replaces the original four separate update methods (updateFirstName,
     * updateLastName, updatePhone, updateAddress).  Those methods violated
     * DRY and required multiple round-trips; this method applies all changes
     * in a single operation.
     *
     * Time complexity: O(log n)
     *   Primary lookup  : O(1)
     *   If lastName changes: O(log n) for secondary index update
     *   Otherwise        : O(1) (field set only)
     *
     * @param contactId  the ID of the contact to update
     * @param firstName  new first name, or null to leave unchanged
     * @param lastName   new last name, or null to leave unchanged
     * @param phone      new phone number, or null to leave unchanged
     * @param address    new address, or null to leave unchanged
     * @throws IllegalArgumentException  if contactId is null/blank, or if any
     *                                   non-null field fails its constraint
     * @throws ContactNotFoundException  if no contact with this ID exists
     */
    public void updateContact(String contactId,
                              String firstName,
                              String lastName,
                              String phone,
                              String address) {

        String id      = validateId(contactId);
        Contact contact = requireContact(id);

        // ── lastName update requires secondary index maintenance ───────
        if (lastName != null) {
            String oldKey = contact.getLastName().toLowerCase();
            contact.setLastName(lastName);              // validates internally
            String newKey = contact.getLastName().toLowerCase();

            if (!oldKey.equals(newKey)) {
                // Remove ID from old TreeMap entry – O(log n).
                List<String> oldList = secondaryIndex.get(oldKey);
                if (oldList != null) {
                    oldList.remove(id);
                    if (oldList.isEmpty()) secondaryIndex.remove(oldKey);
                }
                // Insert ID under new TreeMap entry – O(log n).
                secondaryIndex.computeIfAbsent(newKey, k -> new ArrayList<>()).add(id);
            }
        }

        // ── Remaining fields delegate to Contact's validated setters ───
        if (firstName != null) contact.setFirstName(firstName);
        if (phone     != null) contact.setPhone(phone);
        if (address   != null) contact.setAddress(address);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  READ OPERATIONS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Retrieves a single contact by its unique ID.
     *
     * Time complexity: O(1) average — HashMap.get.
     *
     * @param contactId the ID to look up
     * @return the matching Contact
     * @throws IllegalArgumentException  if contactId is null or blank
     * @throws ContactNotFoundException  if no contact with this ID exists
     */
    public Contact getContact(String contactId) {
        return requireContact(validateId(contactId));
    }

    /**
     * Returns all contacts whose last name starts with the given prefix,
     * in alphabetical order by last name.
     *
     * Uses TreeMap.subMap() to restrict the BST traversal to the relevant
     * key range — no full scan of the data set is performed.
     *
     * Time complexity: O(log n + k)
     *   log n : BST navigation to the start of the prefix range
     *   k     : number of matching contacts retrieved
     *
     * Compare to a naive HashMap scan: O(n) regardless of k.
     * For a data set of 10,000 contacts with 50 matching a prefix,
     * subMap traversal visits ~14 BST nodes vs 10,000 HashMap entries.
     *
     * @param prefix the last-name prefix to search for (case-insensitive)
     * @return an unmodifiable list of matching Contact objects, sorted by
     *         last name; empty list if no matches
     * @throws IllegalArgumentException if prefix is null or blank
     */
    public List<Contact> searchByLastName(String prefix) {
        if (prefix == null || prefix.isBlank())
            throw new IllegalArgumentException(
                "Search prefix must not be null or blank.");

        String lo = prefix.toLowerCase();
        // Construct the exclusive upper bound: increment the last character
        // so that subMap captures all keys that start with lo.
        // E.g., prefix "smi" → range ["smi", "smj").
        String hi = lo.substring(0, lo.length() - 1)
                  + (char)(lo.charAt(lo.length() - 1) + 1);

        // subMap is O(log n) to locate the start position in the BST.
        Map<String, List<String>> range = secondaryIndex.subMap(lo, hi);

        List<Contact> results = new ArrayList<>();
        for (List<String> ids : range.values()) {
            for (String id : ids) {
                Contact c = primaryIndex.get(id);
                if (c != null) results.add(c);
            }
        }
        // Return an unmodifiable view — callers must not mutate the list.
        return Collections.unmodifiableList(results);
    }

    /**
     * Returns the total number of contacts currently stored.
     * Time complexity: O(1) — HashMap.size().
     *
     * @return contact count
     */
    public int size() {
        return primaryIndex.size();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  PRIVATE HELPERS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Validates and sanitises a contactId string.
     * Trims whitespace and rejects null/blank values.
     *
     * @param contactId the raw ID from the caller
     * @return trimmed, non-blank contactId
     * @throws IllegalArgumentException if null or blank after trimming
     */
    private String validateId(String contactId) {
        if (contactId == null || contactId.isBlank())
            throw new IllegalArgumentException(
                "Contact ID must not be null or blank.");
        return contactId.trim();
    }

    /**
     * Looks up a contact by sanitised ID and throws ContactNotFoundException
     * if not present.  Centralises the "record not found" check so every
     * public method that needs an existing contact calls this one helper
     * rather than duplicating the containsKey/throw pattern.
     *
     * Time complexity: O(1) average — HashMap.get.
     *
     * @param id sanitised contactId (already trimmed)
     * @return the Contact record
     * @throws ContactNotFoundException if no record exists for this ID
     */
    private Contact requireContact(String id) {
        Contact contact = primaryIndex.get(id);
        if (contact == null)
            throw new ContactNotFoundException(id);
        return contact;
    }
}
