package contactservice;

/**
 * Contact.java
 * ============
 * Immutable-ID data model representing a single contact record.
 * Enforces field-length constraints on construction and mutation.
 *
 * AUTHOR:   Francisco Sousa
 * Course:   CS 499 – Computer Science Capstone, SNHU
 * Created:  2026-05-26
 * Origin:   CS 320 – Software Test, Automation and QA
 *
 * Enhancement notes (CS 499 Category Two – Algorithms and Data Structures):
 *   The Contact class itself required no structural changes for this
 *   enhancement.  Validation logic was already correct and complete.
 *   The only additions are:
 *     1. This expanded class-level Javadoc header.
 *     2. Inline comments on each validation rule explaining the business
 *        constraint it enforces and why the chosen limit was selected.
 *   These additions satisfy the CS 499 requirement for code comments
 *   that show intent and decision-making (Course Outcome 2).
 *
 * Field constraints (enforced at construction and in all setters):
 *   contactId  – non-null, max 10 characters, immutable after construction
 *   firstName  – non-null, max 10 characters
 *   lastName   – non-null, max 10 characters
 *   phone      – non-null, exactly 10 digits (no formatting characters)
 *   address    – non-null, max 30 characters
 */
public class Contact {

    // contactId is declared final: the identity of a contact record must
    // never change after creation to preserve referential integrity in the
    // ContactService indexes.
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructs a fully validated Contact.
     * All five fields are required; no null values are permitted.
     *
     * @param contactId  unique identifier, max 10 chars
     * @param firstName  given name, max 10 chars
     * @param lastName   family name, max 10 chars
     * @param phone      10-digit phone number string (digits only)
     * @param address    mailing address, max 30 chars
     * @throws IllegalArgumentException if any field fails its constraint
     */
    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {

        // contactId: null check first, then length. The 10-char limit matches
        // the original CS 320 specification; it accommodates alphanumeric IDs
        // such as "CR7", "MJ23", or "C1000000".
        if (contactId == null || contactId.length() > 10)
            throw new IllegalArgumentException("Invalid contact ID: " +
                "must be non-null and at most 10 characters.");

        // firstName / lastName: 10-char limit from spec.
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name: " +
                "must be non-null and at most 10 characters.");
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name: " +
                "must be non-null and at most 10 characters.");

        // phone: must be exactly 10 characters (North American NANP format
        // without separators). The strict equality check prevents partial
        // numbers and overly long strings alike.
        if (phone == null || phone.length() != 10)
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");

        // address: 30-char limit from spec.
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address: " +
                "must be non-null and at most 30 characters.");

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.phone     = phone;
        this.address   = address;
    }

    // ── Getters ────────────────────────────────────────────────────────────

    /** @return the immutable contact ID */
    public String getContactId() { return contactId; }

    /** @return the contact's first name */
    public String getFirstName()  { return firstName; }

    /** @return the contact's last name */
    public String getLastName()   { return lastName;  }

    /** @return the contact's 10-digit phone string */
    public String getPhone()      { return phone;     }

    /** @return the contact's mailing address */
    public String getAddress()    { return address;   }

    // ── Setters (validated) ────────────────────────────────────────────────

    /**
     * Updates the first name.
     * @throws IllegalArgumentException if null or longer than 10 characters
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10)
            throw new IllegalArgumentException("Invalid first name.");
        this.firstName = firstName;
    }

    /**
     * Updates the last name.
     * @throws IllegalArgumentException if null or longer than 10 characters
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10)
            throw new IllegalArgumentException("Invalid last name.");
        this.lastName = lastName;
    }

    /**
     * Updates the phone number.
     * @throws IllegalArgumentException if null or not exactly 10 characters
     */
    public void setPhone(String phone) {
        if (phone == null || phone.length() != 10)
            throw new IllegalArgumentException("Phone must be exactly 10 digits.");
        this.phone = phone;
    }

    /**
     * Updates the mailing address.
     * @throws IllegalArgumentException if null or longer than 30 characters
     */
    public void setAddress(String address) {
        if (address == null || address.length() > 30)
            throw new IllegalArgumentException("Invalid address.");
        this.address = address;
    }
}
