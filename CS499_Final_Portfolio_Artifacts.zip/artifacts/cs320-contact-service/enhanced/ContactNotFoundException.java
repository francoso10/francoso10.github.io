package contactservice;

/**
 * ContactNotFoundException
 * ========================
 * Custom unchecked exception thrown when a contact lookup by ID or name
 * fails to find a matching record in the ContactService store.
 *
 * AUTHOR:   Francisco Sousa
 * Course:   CS 499 – Computer Science Capstone, SNHU
 * Created:  2026-05-26
 * Origin:   CS 320 – Software Test, Automation and QA (enhancement)
 *
 * Enhancement rationale (CS 499 Category Two – Algorithms and Data Structures):
 *   The original ContactService threw generic IllegalArgumentException for both
 *   validation errors (bad input) and lookup failures (ID not found).  Using a
 *   single exception type for two semantically different failure modes forces
 *   callers to inspect the message string to distinguish them — a fragile and
 *   error-prone pattern.  ContactNotFoundException gives callers a specific,
 *   catchable type for the "record not found" case, enabling cleaner error
 *   handling and more descriptive stack traces.
 *
 * Design choice – extends RuntimeException (unchecked):
 *   Lookup failures in a service layer are operational errors that typically
 *   cannot be meaningfully recovered from at the call site (the record either
 *   exists or it does not).  Making this unchecked avoids forcing every caller
 *   to declare a checked exception in its signature, which would add boilerplate
 *   without improving correctness.
 */
public class ContactNotFoundException extends RuntimeException {

    /**
     * Constructs the exception with a message identifying the missing contact.
     *
     * @param contactId the ID that was searched for and not found
     */
    public ContactNotFoundException(String contactId) {
        super("Contact not found for ID: " + contactId);
    }
}
