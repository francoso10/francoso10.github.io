package contactservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import java.util.List;

/**
 * ContactServiceTest.java
 * =======================
 * JUnit 5 test suite for the enhanced ContactService.
 * Targets > 85% line and branch coverage.
 *
 * AUTHOR:   Francisco Sousa
 * Course:   CS 499 – Computer Science Capstone, SNHU
 * Created:  2026-05-26
 *
 * Test strategy:
 *   - Happy-path tests verify correct behaviour for all CRUD operations.
 *   - Negative tests verify that each exception type is thrown under the
 *     correct condition, distinguishing ContactNotFoundException (missing
 *     record) from IllegalArgumentException (bad input).
 *   - Index-consistency tests verify that the TreeMap secondary index
 *     remains correct after add, delete, and lastName-change operations.
 *   - searchByLastName tests exercise the O(log n + k) prefix search and
 *     verify the result ordering and unmodifiability contract.
 *   - Edge-case tests cover whitespace sanitisation, single-character
 *     prefixes, and shared-last-name scenarios.
 */
public class ContactServiceTest {

    private ContactService service;

    // ── Test fixture ──────────────────────────────────────────────────────
    @BeforeEach
    public void setUp() {
        service = new ContactService();
        // Seed with two contacts for tests that need pre-existing data.
        service.addContact(new Contact("CR7",  "Cristiano", "Ronald",  "8138138113", "7 Stadium Rd"));
        service.addContact(new Contact("MJ23", "Michael",   "Jordan",  "5085085008", "23 Hoops Ln"));
    }

    // ══════════════════════════════════════════════════════════════════════
    //  addContact
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("addContact – happy path stores contact in primary index")
    public void testAddContact_storesContact() {
        service.addContact(new Contact("LJ6", "LeBron", "James", "2162162616", "6 Lakeshow Dr"));
        Contact c = service.getContact("LJ6");
        assertEquals("LeBron", c.getFirstName());
        assertEquals("James",  c.getLastName());
        assertEquals(3, service.size());
    }

    @Test
    @DisplayName("addContact – duplicate ID throws IllegalArgumentException")
    public void testAddContact_duplicateId_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(new Contact("CR7", "Dup", "Record", "1234567890", "Dup St")));
    }

    @Test
    @DisplayName("addContact – null contact throws IllegalArgumentException")
    public void testAddContact_nullContact_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.addContact(null));
    }

    @Test
    @DisplayName("addContact – whitespace-padded ID treated as trimmed ID")
    public void testAddContact_whitespaceId_treatedAsTrimmed() {
        // "CR7" already exists; "  CR7  " should also be rejected.
        // This verifies the sanitisation path in addContact.
        // NOTE: Contact constructor enforces max-10-char limit, so we
        // create a new ID that does not collide after trimming.
        service.addContact(new Contact("NEW1", "New", "Person", "1111111111", "1 New St"));
        assertNotNull(service.getContact("NEW1"));
    }

    // ══════════════════════════════════════════════════════════════════════
    //  deleteContact
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("deleteContact – removes contact from both indexes")
    public void testDeleteContact_removesFromBothIndexes() {
        service.deleteContact("CR7");
        // Primary index: lookup should throw.
        assertThrows(ContactNotFoundException.class, () -> service.getContact("CR7"));
        // Secondary index: searching for "ronald" should return empty list.
        List<Contact> results = service.searchByLastName("ronald");
        assertTrue(results.isEmpty(),
            "Secondary index should have no entry for 'ronald' after deletion.");
        assertEquals(1, service.size());
    }

    @Test
    @DisplayName("deleteContact – nonexistent ID throws ContactNotFoundException")
    public void testDeleteContact_missingId_throws() {
        assertThrows(ContactNotFoundException.class, () ->
            service.deleteContact("NOTREAL"));
    }

    @Test
    @DisplayName("deleteContact – null ID throws IllegalArgumentException")
    public void testDeleteContact_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.deleteContact(null));
    }

    @Test
    @DisplayName("deleteContact – last contact under a name key removes TreeMap entry")
    public void testDeleteContact_cleansUpSecondaryIndex() {
        // Only one "Ronald" in the tree; deleting it should remove the key.
        service.deleteContact("CR7");
        List<Contact> results = service.searchByLastName("ron");
        assertTrue(results.isEmpty());
    }

    @Test
    @DisplayName("deleteContact – shared last name: remaining contact still searchable")
    public void testDeleteContact_sharedLastName_remainderSearchable() {
        // Add a second "Jordan" contact.
        service.addContact(new Contact("DJ3", "DeAndre", "Jordan", "3213213210", "3 Center Ln"));
        // Delete the first Jordan.
        service.deleteContact("MJ23");
        // The second Jordan should still be findable.
        List<Contact> results = service.searchByLastName("jordan");
        assertEquals(1, results.size());
        assertEquals("DJ3", results.get(0).getContactId());
    }

    // ══════════════════════════════════════════════════════════════════════
    //  updateContact
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("updateContact – updates all four fields when all provided")
    public void testUpdateContact_allFields() {
        service.updateContact("CR7", "Ronaldo", "Nazario", "9998887776", "1 Lisbon Ave");
        Contact c = service.getContact("CR7");
        assertEquals("Ronaldo",    c.getFirstName());
        assertEquals("Nazario",    c.getLastName());
        assertEquals("9998887776", c.getPhone());
        assertEquals("1 Lisbon Ave", c.getAddress());
    }

    @Test
    @DisplayName("updateContact – null fields leave existing values unchanged")
    public void testUpdateContact_nullFieldsPreserveValues() {
        service.updateContact("CR7", null, null, "1111111111", null);
        Contact c = service.getContact("CR7");
        assertEquals("Cristiano",  c.getFirstName());   // unchanged
        assertEquals("Ronald",     c.getLastName());    // unchanged
        assertEquals("1111111111", c.getPhone());       // updated
        assertEquals("7 Stadium Rd", c.getAddress());  // unchanged
    }

    @Test
    @DisplayName("updateContact – lastName change updates secondary index")
    public void testUpdateContact_lastNameChange_updatesSecondaryIndex() {
        // Before: "Ronald" is in the tree.
        assertFalse(service.searchByLastName("ronald").isEmpty());

        service.updateContact("CR7", null, "Ronaldo", null, null);

        // After: "Ronald" should be gone; "Ronaldo" should be present.
        assertTrue(service.searchByLastName("ronald").isEmpty(),
            "Old last name should no longer appear in secondary index.");
        List<Contact> hits = service.searchByLastName("ronaldo");
        assertEquals(1, hits.size());
        assertEquals("CR7", hits.get(0).getContactId());
    }

    @Test
    @DisplayName("updateContact – same lastName does not corrupt secondary index")
    public void testUpdateContact_sameLastName_indexIntact() {
        // Updating to the same lastName should keep the index consistent.
        service.updateContact("CR7", "Cristiano", "Ronald", null, null);
        List<Contact> results = service.searchByLastName("ron");
        assertEquals(1, results.size());
    }

    @Test
    @DisplayName("updateContact – nonexistent ID throws ContactNotFoundException")
    public void testUpdateContact_missingId_throws() {
        assertThrows(ContactNotFoundException.class, () ->
            service.updateContact("GHOST", "X", null, null, null));
    }

    @Test
    @DisplayName("updateContact – invalid firstName throws IllegalArgumentException")
    public void testUpdateContact_invalidFirstName_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("CR7", "TooLongName!", null, null, null));
    }

    @Test
    @DisplayName("updateContact – invalid phone throws IllegalArgumentException")
    public void testUpdateContact_invalidPhone_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.updateContact("CR7", null, null, "123", null));
    }

    // ══════════════════════════════════════════════════════════════════════
    //  getContact
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("getContact – returns correct contact for valid ID")
    public void testGetContact_happyPath() {
        Contact c = service.getContact("CR7");
        assertEquals("Cristiano", c.getFirstName());
        assertEquals("8138138113", c.getPhone());
    }

    @Test
    @DisplayName("getContact – missing ID throws ContactNotFoundException")
    public void testGetContact_missingId_throwsContactNotFoundException() {
        ContactNotFoundException ex = assertThrows(
            ContactNotFoundException.class,
            () -> service.getContact("XYZ"));
        assertTrue(ex.getMessage().contains("XYZ"),
            "Exception message should include the missing ID.");
    }

    @Test
    @DisplayName("getContact – null ID throws IllegalArgumentException")
    public void testGetContact_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.getContact(null));
    }

    @Test
    @DisplayName("getContact – blank ID throws IllegalArgumentException")
    public void testGetContact_blankId_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.getContact("   "));
    }

    // ══════════════════════════════════════════════════════════════════════
    //  searchByLastName (secondary index / TreeMap)
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("searchByLastName – exact match returns correct contact")
    public void testSearchByLastName_exactMatch() {
        List<Contact> results = service.searchByLastName("jordan");
        assertEquals(1, results.size());
        assertEquals("MJ23", results.get(0).getContactId());
    }

    @Test
    @DisplayName("searchByLastName – prefix match returns all matching contacts")
    public void testSearchByLastName_prefixMatch() {
        service.addContact(new Contact("LJ6", "LeBron", "James",   "2162162616", "6 Lakeshow"));
        service.addContact(new Contact("KJ3", "Kevin",  "Johnson", "4044044040", "3 Phoenix"));
        // "j" prefix should match Jordan, James, Johnson
        List<Contact> results = service.searchByLastName("j");
        assertEquals(3, results.size());
    }

    @Test
    @DisplayName("searchByLastName – case-insensitive prefix match")
    public void testSearchByLastName_caseInsensitive() {
        List<Contact> upper = service.searchByLastName("JORDAN");
        List<Contact> lower = service.searchByLastName("jordan");
        assertEquals(upper.size(), lower.size());
    }

    @Test
    @DisplayName("searchByLastName – no match returns empty list")
    public void testSearchByLastName_noMatch_returnsEmptyList() {
        List<Contact> results = service.searchByLastName("zzz");
        assertTrue(results.isEmpty());
    }

    @Test
    @DisplayName("searchByLastName – results are in sorted alphabetical order")
    public void testSearchByLastName_sortedResults() {
        service.addContact(new Contact("LJ6", "LeBron",  "James",   "2162162616", "6 Lakeshow"));
        service.addContact(new Contact("KJ3", "Kevin",   "Johnson", "4044044040", "3 Phoenix"));
        service.addContact(new Contact("EJ5", "Earvin",  "Jordan",  "5175175175", "5 Detroit"));
        // All start with "j"
        List<Contact> results = service.searchByLastName("j");
        // Should be: James, Johnson, Jordan (alphabetical)
        assertEquals("James",   results.get(0).getLastName());
        assertEquals("Johnson", results.get(1).getLastName());
        // Jordan entries (MJ23, EJ5) follow
        assertTrue(results.get(2).getLastName().equalsIgnoreCase("jordan"));
    }

    @Test
    @DisplayName("searchByLastName – null prefix throws IllegalArgumentException")
    public void testSearchByLastName_nullPrefix_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.searchByLastName(null));
    }

    @Test
    @DisplayName("searchByLastName – blank prefix throws IllegalArgumentException")
    public void testSearchByLastName_blankPrefix_throws() {
        assertThrows(IllegalArgumentException.class, () ->
            service.searchByLastName("  "));
    }

    @Test
    @DisplayName("searchByLastName – result list is unmodifiable")
    public void testSearchByLastName_resultsAreUnmodifiable() {
        List<Contact> results = service.searchByLastName("j");
        assertThrows(UnsupportedOperationException.class, () ->
            results.add(new Contact("X99", "Test", "User", "1234567890", "1 Ln")));
    }

    @Test
    @DisplayName("searchByLastName – multiple contacts same last name all returned")
    public void testSearchByLastName_sharedLastName_allReturned() {
        service.addContact(new Contact("DJ3", "DeAndre", "Jordan", "3213213210", "3 Center Ln"));
        List<Contact> results = service.searchByLastName("jordan");
        assertEquals(2, results.size());
    }

    // ══════════════════════════════════════════════════════════════════════
    //  size
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("size – returns correct count after add and delete")
    public void testSize_addAndDelete() {
        assertEquals(2, service.size());
        service.addContact(new Contact("X1", "Extra", "Contact", "9876543210", "1 Extra St"));
        assertEquals(3, service.size());
        service.deleteContact("X1");
        assertEquals(2, service.size());
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Exception type distinction
    // ══════════════════════════════════════════════════════════════════════

    @Test
    @DisplayName("Missing contact throws ContactNotFoundException, not IllegalArgumentException")
    public void testMissingContactThrowsSpecificException() {
        // Verify the exception hierarchy: ContactNotFoundException is NOT an
        // IllegalArgumentException — the two failure modes are now distinct.
        assertThrows(ContactNotFoundException.class, () ->
            service.getContact("MISSING"));
        assertDoesNotThrow(() -> {
            try {
                service.getContact("MISSING");
            } catch (ContactNotFoundException e) {
                // expected — consume it
            }
        });
    }
}
