# CS 330 OpenGL Castle Scene

This folder contains the original and enhanced source files for the Software Engineering and Design artifact.

- `original/` contains the original `SceneManager.cpp` selected for review.
- `enhanced/` contains the enhanced `SceneManager.cpp`, `Logger.h`, and `scene_config.json`.
- `narrative/` contains the submitted enhancement narrative in Word and PDF formats.
