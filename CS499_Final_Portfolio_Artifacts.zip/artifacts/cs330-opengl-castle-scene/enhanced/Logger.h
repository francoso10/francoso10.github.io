/////////////////////////////////////////////////////////////////////////////////
// Logger.h
// ========
// Lightweight structured logger for the CS 330 OpenGL Castle Scene project.
// Provides severity-tagged console output (INFO, WARNING, ERROR) so that
// diagnostic messages can be filtered and traced without a third-party library.
//
// AUTHOR: Francisco Sousa
// Course: CS 499 – Computer Science Capstone, SNHU
// Created: 2026-05-19
// Enhancement: Category One – Software Design and Engineering
//
// Design intent:
//   This header-only class replaces scattered std::cout / std::cerr calls with
//   a single, consistent interface.  Each message is prefixed with a severity
//   level and the calling context so that output can be read at a glance during
//   debugging.  The static interface avoids the need to pass a Logger instance
//   through every manager.
//
// Usage:
//   Logger::info("SceneManager", "Texture loaded: textures/brick_wall.JPG");
//   Logger::warn("SceneManager", "Anisotropy extension not supported; skipping.");
//   Logger::error("SceneManager", "Failed to load texture: textures/missing.JPG");
/////////////////////////////////////////////////////////////////////////////////

#pragma once
#include <iostream>
#include <string>

class Logger
{
public:
    // ------------------------------------------------------------------
    // info()
    // Log an informational message.  Used for successful operations and
    // normal state transitions (e.g., texture loaded, scene built).
    // Parameters:
    //   context – name of the calling class or function (for filtering)
    //   message – human-readable description of the event
    // ------------------------------------------------------------------
    static void info(const std::string& context, const std::string& message)
    {
        std::cout << "[INFO]  [" << context << "] " << message << std::endl;
    }

    // ------------------------------------------------------------------
    // warn()
    // Log a warning that does not halt execution but signals a degraded
    // state (e.g., optional extension unavailable, fallback applied).
    // ------------------------------------------------------------------
    static void warn(const std::string& context, const std::string& message)
    {
        std::cout << "[WARN]  [" << context << "] " << message << std::endl;
    }

    // ------------------------------------------------------------------
    // error()
    // Log a recoverable error.  The caller decides whether to abort or
    // continue after calling this (e.g., texture missing – use fallback).
    // ------------------------------------------------------------------
    static void error(const std::string& context, const std::string& message)
    {
        std::cerr << "[ERROR] [" << context << "] " << message << std::endl;
    }
};
