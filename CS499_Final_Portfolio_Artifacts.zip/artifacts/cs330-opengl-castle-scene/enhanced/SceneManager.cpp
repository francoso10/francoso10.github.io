/////////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ================
// Manages the preparation and rendering of the 3D castle scene:
//   textures, materials, lighting, and all scene geometry.
//
// AUTHOR:      Francisco Sousa
// Course:      CS 499 – Computer Science Capstone, SNHU
// Created:     2026-05-19
// Origin:      Originally authored by Brian Battersby for CS-330
//              (Computational Graphics and Visualization, Nov. 1, 2023).
//              Substantially refactored for CS 499 Milestone Two.
//
// Enhancement summary (CS 499 Category One – Software Design & Engineering):
//   1. JSON-driven configuration  – All hard-coded positions, scales, texture
//      paths, material properties, and light parameters are now loaded from
//      scene_config.json via nlohmann/json.  Scene content can be modified
//      without recompiling the C++ source (Course Outcome 4).
//
//   2. Structured error logging   – All std::cout / std::cerr calls replaced
//      with Logger::info / Logger::warn / Logger::error so every message is
//      tagged with severity and calling context (Course Outcome 5).
//
//   3. Defensive programming      – Every file-I/O path, JSON key access, and
//      OpenGL state transition is guarded.  Missing keys fall back to safe
//      defaults; missing textures substitute a 1x1 white fallback texture so
//      the renderer never crashes on a bad asset path (Course Outcome 5).
//
//   4. Separation of concerns     – Scene-building logic is split into focused
//      private helpers (LoadTexturesFromConfig, LoadMaterialsFromConfig,
//      SetupLightingFromConfig, BuildSceneFromConfig) that each do exactly one
//      thing and log their own errors.  PrepareScene() now orchestrates these
//      helpers rather than doing everything inline (Course Outcome 4).
//
//   5. Modern C++ practices       – Lambda captures in garden/lamp helpers
//      replaced with private member functions to improve readability and
//      testability; raw pointer null checks replaced with early-return guards.
//
// Alignment with CS 499 Course Outcomes:
//   CO 4 – Innovative techniques, skills, and tools in computing practices
//   CO 5 – Security mindset: anticipating failure modes, validating inputs,
//           preventing crashes from missing or malformed external data
/////////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

// JSON parsing – header-only nlohmann/json (single-include)
// Place json.hpp in the project root or adjust the path below.
#include "json.hpp"
using json = nlohmann::json;

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include "Logger.h"

#include <glm/gtx/transform.hpp>
#include <fstream>
#include <iostream>
#include <stdexcept>

// ── OpenGL anisotropic filtering extension tokens ────────────────────────────
#ifndef GL_TEXTURE_MAX_ANISOTROPY_EXT
#define GL_TEXTURE_MAX_ANISOTROPY_EXT     0x84FE
#endif
#ifndef GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT
#define GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT 0x84FF
#endif

// ── Default configuration file path ─────────────────────────────────────────
// Can be overridden by passing a different path to PrepareScene().
static constexpr const char* DEFAULT_CONFIG_PATH = "scene_config.json";

// ── Ground height: kept as a constexpr for geometry helpers that do not
//    use the JSON value (e.g., topiary math relative to the ground plane).
//    The authoritative value is read from scene_config.json at runtime.
static constexpr float GROUND_Y = 4.0f;

// ── Shader uniform name constants ────────────────────────────────────────────
namespace
{
    const char* g_ModelName       = "model";
    const char* g_ColorValueName  = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName  = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 * SceneManager() – constructor
 * Initialises manager pointers and allocates the mesh helper.
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager),
      m_basicMeshes(new ShapeMeshes()),
      m_loadedTextures(0)
{
    Logger::info("SceneManager", "SceneManager constructed.");
}

/***********************************************************
 * ~SceneManager() – destructor
 * Releases GPU texture memory and frees the mesh helper.
 ***********************************************************/
SceneManager::~SceneManager()
{
    DestroyGLTextures();
    delete m_basicMeshes;
    m_basicMeshes    = nullptr;
    m_pShaderManager = nullptr;
    Logger::info("SceneManager", "SceneManager destroyed; GPU textures released.");
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PRIVATE HELPERS – configuration loading
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * LoadConfig()
 * Opens and parses the JSON configuration file.
 * Returns an empty json object on failure rather than
 * throwing, so callers can fall back gracefully.
 ***********************************************************/
json SceneManager::LoadConfig(const std::string& configPath)
{
    // Validate that the path string is non-empty before attempting I/O.
    if (configPath.empty())
    {
        Logger::error("SceneManager::LoadConfig",
            "Config path is empty. Using built-in defaults.");
        return json{};
    }

    std::ifstream file(configPath);
    if (!file.is_open())
    {
        Logger::error("SceneManager::LoadConfig",
            "Cannot open config file: " + configPath +
            ". Using built-in defaults.");
        return json{};
    }

    json cfg;
    try
    {
        file >> cfg;
        Logger::info("SceneManager::LoadConfig",
            "Config loaded successfully: " + configPath);
    }
    catch (const json::parse_error& ex)
    {
        Logger::error("SceneManager::LoadConfig",
            std::string("JSON parse error: ") + ex.what() +
            ". Using built-in defaults.");
        return json{};
    }
    return cfg;
}

/***********************************************************
 * LoadTexturesFromConfig()
 * Iterates the "textures" array in the JSON config and
 * calls CreateGLTexture for each entry.  Missing "path" or
 * "tag" keys are skipped with a warning rather than crashing.
 ***********************************************************/
void SceneManager::LoadTexturesFromConfig(const json& cfg)
{
    // Guard: key must exist and be an array.
    if (!cfg.contains("textures") || !cfg["textures"].is_array())
    {
        Logger::warn("SceneManager::LoadTexturesFromConfig",
            "No 'textures' array found in config. No textures loaded.");
        return;
    }

    for (const auto& entry : cfg["textures"])
    {
        // Validate required keys before accessing them.
        if (!entry.contains("path") || !entry.contains("tag"))
        {
            Logger::warn("SceneManager::LoadTexturesFromConfig",
                "Texture entry missing 'path' or 'tag' key – skipped.");
            continue;
        }

        std::string path = entry["path"].get<std::string>();
        std::string tag  = entry["tag"].get<std::string>();

        // CreateGLTexture logs its own success/failure messages.
        if (!CreateGLTexture(path.c_str(), tag))
        {
            // A failed texture load is non-fatal: CreateFallbackTexture
            // inserts a 1x1 white texture so subsequent draw calls do not
            // crash or render with undefined sampler state.
            Logger::warn("SceneManager::LoadTexturesFromConfig",
                "Fallback white texture inserted for tag: " + tag);
            CreateFallbackTexture(tag);
        }
    }

    BindGLTextures();
}

/***********************************************************
 * LoadMaterialsFromConfig()
 * Reads the "materials" array and populates m_objectMaterials.
 * Defaults (diffuse=white, specular=grey, shininess=8) are
 * applied for any missing numeric fields.
 ***********************************************************/
void SceneManager::LoadMaterialsFromConfig(const json& cfg)
{
    if (!cfg.contains("materials") || !cfg["materials"].is_array())
    {
        Logger::warn("SceneManager::LoadMaterialsFromConfig",
            "No 'materials' array found in config. No materials loaded.");
        return;
    }

    for (const auto& entry : cfg["materials"])
    {
        if (!entry.contains("tag"))
        {
            Logger::warn("SceneManager::LoadMaterialsFromConfig",
                "Material entry missing 'tag' key – skipped.");
            continue;
        }

        OBJECT_MATERIAL mat;
        mat.tag = entry["tag"].get<std::string>();

        // Defensive: use value() overloads so missing keys get safe defaults.
        auto readVec3 = [&](const std::string& key, glm::vec3 def) -> glm::vec3
        {
            if (entry.contains(key) && entry[key].is_array() && entry[key].size() == 3)
                return glm::vec3(entry[key][0], entry[key][1], entry[key][2]);
            Logger::warn("SceneManager::LoadMaterialsFromConfig",
                "Key '" + key + "' missing for material '" + mat.tag +
                "'. Using default.");
            return def;
        };

        mat.diffuseColor  = readVec3("diffuse",  glm::vec3(1.0f));
        mat.specularColor = readVec3("specular", glm::vec3(0.5f));
        mat.shininess     = entry.value("shininess", 8.0f);

        m_objectMaterials.push_back(mat);
        Logger::info("SceneManager::LoadMaterialsFromConfig",
            "Material registered: " + mat.tag);
    }
}

/***********************************************************
 * SetupLightingFromConfig()
 * Configures directional and point lights from the JSON
 * "lighting" block.  Each light is individually guarded so
 * a missing point-light entry does not disable all lighting.
 ***********************************************************/
void SceneManager::SetupLightingFromConfig(const json& cfg)
{
    // Guard: shader manager must be valid before issuing uniform calls.
    if (!m_pShaderManager)
    {
        Logger::error("SceneManager::SetupLightingFromConfig",
            "ShaderManager is null – cannot set lighting uniforms.");
        return;
    }

    if (!cfg.contains("lighting"))
    {
        Logger::warn("SceneManager::SetupLightingFromConfig",
            "No 'lighting' key in config. Scene will be unlit.");
        return;
    }

    const json& lighting = cfg["lighting"];

    // ── Directional light ─────────────────────────────────────────────
    if (lighting.contains("directional"))
    {
        const json& dir = lighting["directional"];
        bool active = dir.value("active", false);
        m_pShaderManager->setBoolValue("directionalLight.bActive", active);

        if (active)
        {
            auto v3 = [&](const std::string& k, glm::vec3 def) -> glm::vec3
            {
                if (dir.contains(k) && dir[k].is_array() && dir[k].size() == 3)
                    return glm::vec3(dir[k][0], dir[k][1], dir[k][2]);
                return def;
            };
            m_pShaderManager->setVec3Value("directionalLight.direction",
                v3("direction", glm::vec3(-0.5f, -1.0f, -0.3f)));
            m_pShaderManager->setVec3Value("directionalLight.ambient",
                v3("ambient",   glm::vec3(0.4f, 0.35f, 0.3f)));
            m_pShaderManager->setVec3Value("directionalLight.diffuse",
                v3("diffuse",   glm::vec3(0.8f, 0.75f, 0.7f)));
            m_pShaderManager->setVec3Value("directionalLight.specular",
                v3("specular",  glm::vec3(0.5f)));
            Logger::info("SceneManager::SetupLightingFromConfig",
                "Directional light configured.");
        }
    }

    // ── Point lights ──────────────────────────────────────────────────
    if (!lighting.contains("point_lights") || !lighting["point_lights"].is_array())
    {
        Logger::warn("SceneManager::SetupLightingFromConfig",
            "No 'point_lights' array in config.");
        return;
    }

    const json& pts = lighting["point_lights"];
    for (size_t i = 0; i < pts.size(); ++i)
    {
        const json& pt = pts[i];
        std::string prefix = "pointLights[" + std::to_string(i) + "]";
        bool active = pt.value("active", false);
        m_pShaderManager->setBoolValue(prefix + ".bActive", active);

        if (!active) continue;

        auto v3 = [&](const std::string& k, glm::vec3 def) -> glm::vec3
        {
            if (pt.contains(k) && pt[k].is_array() && pt[k].size() == 3)
                return glm::vec3(pt[k][0], pt[k][1], pt[k][2]);
            return def;
        };

        m_pShaderManager->setVec3Value(prefix + ".position",
            v3("position", glm::vec3(0.0f, 10.0f, 0.0f)));
        m_pShaderManager->setVec3Value(prefix + ".ambient",
            v3("ambient",  glm::vec3(0.1f)));
        m_pShaderManager->setVec3Value(prefix + ".diffuse",
            v3("diffuse",  glm::vec3(1.0f)));
        m_pShaderManager->setVec3Value(prefix + ".specular",
            v3("specular", glm::vec3(1.0f)));
        m_pShaderManager->setFloatValue(prefix + ".constant",
            pt.value("constant",  1.0f));
        m_pShaderManager->setFloatValue(prefix + ".linear",
            pt.value("linear",    0.09f));
        m_pShaderManager->setFloatValue(prefix + ".quadratic",
            pt.value("quadratic", 0.032f));

        Logger::info("SceneManager::SetupLightingFromConfig",
            "Point light " + std::to_string(i) + " configured.");
    }
}

/***********************************************************
 * BuildSceneFromConfig()
 * Reads tower, wall, topiary, and lamp arrays from the JSON
 * config and delegates to the existing render helpers.
 * Missing arrays produce warnings, not crashes.
 ***********************************************************/
void SceneManager::BuildSceneFromConfig(const json& cfg)
{
    // ── Helper: safely read a 3-element JSON array into glm::vec3 ─────
    auto readVec3 = [](const json& node, const std::string& key,
                       glm::vec3 def) -> glm::vec3
    {
        if (node.contains(key) && node[key].is_array() && node[key].size() == 3)
            return glm::vec3(node[key][0], node[key][1], node[key][2]);
        return def;
    };

    // ── Towers ────────────────────────────────────────────────────────
    if (cfg.contains("towers") && cfg["towers"].is_array())
    {
        for (const auto& t : cfg["towers"])
        {
            glm::vec3 pos   = readVec3(t, "position", glm::vec3(0.0f));
            glm::vec3 scale = readVec3(t, "scale",    glm::vec3(1.0f, 3.0f, 1.0f));
            RenderTower(pos, scale);
        }
        Logger::info("SceneManager::BuildSceneFromConfig",
            "Towers rendered from config: " +
            std::to_string(cfg["towers"].size()));
    }
    else
    {
        Logger::warn("SceneManager::BuildSceneFromConfig",
            "No 'towers' array in config – no towers rendered.");
    }

    // ── Front door (always attached to first tower in config) ─────────
    if (cfg.contains("towers") && !cfg["towers"].empty())
    {
        const json& firstTower = cfg["towers"][0];
        glm::vec3 tPos   = readVec3(firstTower, "position", glm::vec3(0.0f, GROUND_Y, -1.0f));
        glm::vec3 tScale = readVec3(firstTower, "scale",    glm::vec3(1.5f, 4.0f, 1.5f));
        RenderFrontDoor(tPos, tScale);
    }

    // ── Connecting walls ──────────────────────────────────────────────
    if (cfg.contains("walls") && cfg["walls"].is_array())
    {
        for (const auto& w : cfg["walls"])
        {
            glm::vec3 scale = readVec3(w, "scale",    glm::vec3(1.0f));
            glm::vec3 pos   = readVec3(w, "position", glm::vec3(0.0f));
            float uU = w.contains("uv") && w["uv"].size() >= 1 ?
                        w["uv"][0].get<float>() : 1.0f;
            float uV = w.contains("uv") && w["uv"].size() >= 2 ?
                        w["uv"][1].get<float>() : 1.0f;

            SetTransformations(scale, 0, 0, 0, pos);
            SetShaderMaterial("turretMat");
            SetShaderTexture("wall");
            SetTextureUVScale(uU, uV);
            m_basicMeshes->DrawBoxMesh();
        }
        Logger::info("SceneManager::BuildSceneFromConfig",
            "Walls rendered from config: " +
            std::to_string(cfg["walls"].size()));
    }
    else
    {
        Logger::warn("SceneManager::BuildSceneFromConfig",
            "No 'walls' array in config – no connecting walls rendered.");
    }

    // ── Topiary balls ─────────────────────────────────────────────────
    if (cfg.contains("topiary_balls") && cfg["topiary_balls"].is_array())
    {
        for (const auto& ball : cfg["topiary_balls"])
        {
            glm::vec3 pos = readVec3(ball, "position", glm::vec3(0.0f, GROUND_Y, 0.0f));
            float     r   = ball.value("radius", 0.5f);
            DrawTopiaryBall(pos, r);
        }
    }

    // ── Topiary spirals ───────────────────────────────────────────────
    if (cfg.contains("topiary_spirals") && cfg["topiary_spirals"].is_array())
    {
        for (const auto& spiral : cfg["topiary_spirals"])
        {
            float bx = spiral.value("base_x", 0.0f);
            float bz = spiral.value("base_z", 0.0f);
            DrawTopiarySpiral(glm::vec3(bx, GROUND_Y, bz));
        }
    }

    // ── Lamps ─────────────────────────────────────────────────────────
    if (cfg.contains("lamps") && cfg["lamps"].is_array())
    {
        for (const auto& lamp : cfg["lamps"])
        {
            float x = lamp.value("x", 0.0f);
            float z = lamp.value("z", 0.0f);
            DrawLamp(x, z);
        }
        Logger::info("SceneManager::BuildSceneFromConfig",
            "Lamps rendered from config: " +
            std::to_string(cfg["lamps"].size()));
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
//  TEXTURE MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * CreateGLTexture()
 * Loads an image from disk and uploads it to the GPU.
 * Returns false (and logs an error) if the file cannot be
 * opened or the format is unsupported, without aborting.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    // Guard: reject null or empty filenames before any I/O.
    if (!filename || filename[0] == '\0')
    {
        Logger::error("SceneManager::CreateGLTexture",
            "Null or empty filename passed for tag: " + tag);
        return false;
    }

    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (!image)
    {
        Logger::error("SceneManager::CreateGLTexture",
            std::string("stbi_load failed for: ") + filename);
        return false;
    }

    Logger::info("SceneManager::CreateGLTexture",
        std::string("Loaded ") + filename +
        " [" + std::to_string(width) + "x" + std::to_string(height) +
        ", ch=" + std::to_string(colorChannels) + "]");

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // Wrapping
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // Filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // Upload pixel data – only RGB and RGBA are supported.
    if (colorChannels == 3)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8,  width, height, 0,
                     GL_RGB,  GL_UNSIGNED_BYTE, image);
    else if (colorChannels == 4)
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0,
                     GL_RGBA, GL_UNSIGNED_BYTE, image);
    else
    {
        Logger::warn("SceneManager::CreateGLTexture",
            std::string("Unsupported channel count (") +
            std::to_string(colorChannels) + ") for: " + filename);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return false;
    }

    glGenerateMipmap(GL_TEXTURE_2D);

    // ── Anisotropic filtering (optional extension) ────────────────────
    // Clear any pending GL errors before querying the extension so we do
    // not misinterpret a stale INVALID_ENUM as a query failure.
    while (glGetError() != GL_NO_ERROR) {}

    GLfloat maxAniso = 0.0f;
    glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT, &maxAniso);
    if (glGetError() == GL_NO_ERROR && maxAniso > 0.0f)
    {
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT, maxAniso);
        while (glGetError() != GL_NO_ERROR) {}   // clear any stray error
    }
    else
    {
        Logger::warn("SceneManager::CreateGLTexture",
            "Anisotropic filtering not available – skipping for: " +
            std::string(filename));
    }

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    // Store the texture ID and its tag for later lookup.
    m_textureIDs[m_loadedTextures].ID  = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

/***********************************************************
 * CreateFallbackTexture()
 * Inserts a 1×1 white texture under the given tag so that
 * any draw call referencing a missing texture renders with
 * a neutral white colour instead of crashing or producing
 * undefined sampler behaviour.
 ***********************************************************/
void SceneManager::CreateFallbackTexture(const std::string& tag)
{
    GLuint textureID = 0;
    unsigned char white[4] = { 255, 255, 255, 255 };   // 1×1 RGBA white pixel

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, 1, 1, 0,
                 GL_RGBA, GL_UNSIGNED_BYTE, white);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures].ID  = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    Logger::info("SceneManager::CreateFallbackTexture",
        "1x1 white fallback texture created for tag: " + tag);
}

/***********************************************************
 * BindGLTextures()
 * Binds all loaded textures to consecutive texture units.
 * Caps binding at the driver's actual GL_MAX_TEXTURE_IMAGE_UNITS
 * to avoid undefined behaviour on hardware with fewer units.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    GLint maxUnits = 0;
    glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &maxUnits);
    int count = std::min(m_loadedTextures, static_cast<int>(maxUnits));

    for (int i = 0; i < count; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }

    Logger::info("SceneManager::BindGLTextures",
        "Bound " + std::to_string(count) + " texture(s).");
}

/***********************************************************
 * DestroyGLTextures()
 * Releases all GPU texture objects and resets the count.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
        glDeleteTextures(1, &m_textureIDs[i].ID);
    m_loadedTextures = 0;
}

/***********************************************************
 * FindTextureID() – returns OpenGL texture object ID by tag.
 * Returns -1 if the tag is not found (caller must handle).
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
        if (m_textureIDs[i].tag == tag) return m_textureIDs[i].ID;
    return -1;
}

/***********************************************************
 * FindTextureSlot() – returns texture unit index by tag.
 * Returns -1 if the tag is not found.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
        if (m_textureIDs[i].tag == tag) return i;
    return -1;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MATERIAL MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * FindMaterial()
 * Searches m_objectMaterials by tag and copies the result
 * into the output parameter.  Returns false if not found.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& m : m_objectMaterials)
    {
        if (m.tag == tag)
        {
            material.diffuseColor  = m.diffuseColor;
            material.specularColor = m.specularColor;
            material.shininess     = m.shininess;
            return true;
        }
    }
    return false;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  SHADER UNIFORM SETTERS
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * SetTransformations()
 * Computes the model matrix from SRT components and uploads
 * it to the shader.  Guards the shader manager pointer
 * before issuing the uniform call.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 scale       = glm::scale(scaleXYZ);
    glm::mat4 rotationX   = glm::rotate(glm::radians(XrotationDegrees),
                                         glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY   = glm::rotate(glm::radians(YrotationDegrees),
                                         glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ   = glm::rotate(glm::radians(ZrotationDegrees),
                                         glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    glm::mat4 modelView   = translation * rotationZ * rotationY * rotationX * scale;

    // Guard: early return if the shader manager has been destroyed.
    if (!m_pShaderManager)
    {
        Logger::error("SceneManager::SetTransformations",
            "ShaderManager is null – model uniform not set.");
        return;
    }
    m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 * SetShaderColor()
 * Disables texture sampling and sets a flat RGBA colour.
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    if (!m_pShaderManager) return;
    glm::vec4 color(redColorValue, greenColorValue, blueColorValue, alphaValue);
    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, color);
}

/***********************************************************
 * SetShaderTexture()
 * Looks up the texture slot by tag and enables texture
 * sampling for subsequent draw calls.  Falls back to
 * flat-colour mode with a warning if the tag is unknown,
 * preventing sampling from an unbound texture unit.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (!m_pShaderManager) return;

    int textureSlot = FindTextureSlot(textureTag);
    if (textureSlot < 0)
    {
        Logger::warn("SceneManager::SetShaderTexture",
            "Tag '" + textureTag + "' not found – disabling texture.");
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        return;
    }

    m_pShaderManager->setIntValue(g_UseTextureName, true);
    m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
}

/***********************************************************
 * SetTextureUVScale()
 * Uploads UV tiling factors to the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (!m_pShaderManager) return;
    m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 * SetShaderMaterial()
 * Looks up a material by tag and uploads its Phong
 * parameters to the shader.  Logs a warning if not found.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (!m_pShaderManager || m_objectMaterials.empty()) return;

    OBJECT_MATERIAL material;
    if (!FindMaterial(materialTag, material))
    {
        Logger::warn("SceneManager::SetShaderMaterial",
            "Material tag '" + materialTag + "' not found – uniforms not set.");
        return;
    }

    m_pShaderManager->setVec3Value("material.diffuseColor",  material.diffuseColor);
    m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
    m_pShaderManager->setFloatValue("material.shininess",    material.shininess);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PUBLIC ENTRY POINTS
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * PrepareScene()
 * Orchestrates all one-time scene setup:
 *   1. Load and parse the JSON config (with fallback to defaults).
 *   2. Load textures from the config's "textures" array.
 *   3. Load primitive meshes (unchanged from original).
 *   4. Load materials from the config's "materials" array.
 *   5. Configure lighting from the config's "lighting" block.
 *
 * By delegating to focused helpers, this function is now a
 * high-level coordinator rather than a monolithic procedure.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    Logger::info("SceneManager::PrepareScene", "Starting scene preparation.");

    // ── Step 1: Load JSON configuration ──────────────────────────────
    json cfg = LoadConfig(DEFAULT_CONFIG_PATH);

    // ── Step 2: Load textures ─────────────────────────────────────────
    LoadTexturesFromConfig(cfg);

    // ── Step 3: Load primitive meshes ────────────────────────────────
    // Mesh loading is not config-driven: these are the fixed primitive
    // types that the scene's geometry is assembled from.
    m_basicMeshes->LoadPlaneMesh();     // ground plane, door card
    m_basicMeshes->LoadCylinderMesh();  // tower bodies, lamp poles, topiary trunks
    m_basicMeshes->LoadConeMesh();      // tower roofs
    m_basicMeshes->LoadSphereMesh();    // topiary balls, lamp globes
    m_basicMeshes->LoadBoxMesh();       // connecting wall segments
    Logger::info("SceneManager::PrepareScene", "Primitive meshes loaded.");

    // ── Step 4: Load materials ────────────────────────────────────────
    LoadMaterialsFromConfig(cfg);

    // ── Step 5: Configure lighting ───────────────────────────────────
    SetupLightingFromConfig(cfg);

    Logger::info("SceneManager::PrepareScene", "Scene preparation complete.");
}

/***********************************************************
 * RenderScene()
 * Called every frame.  Renders the ground plane and then
 * delegates to BuildSceneFromConfig() to place all other
 * scene objects using data read from scene_config.json.
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Guard: shader manager must be live before issuing draw calls.
    if (!m_pShaderManager)
    {
        Logger::error("SceneManager::RenderScene",
            "ShaderManager is null – aborting render.");
        return;
    }

    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // ── Ground plane ─────────────────────────────────────────────────
    // Read ground parameters from config if available; otherwise use
    // the constexpr GROUND_Y default so the scene is always visible.
    json cfg = LoadConfig(DEFAULT_CONFIG_PATH);

    float groundY = GROUND_Y;
    glm::vec3 groundScale(20.0f, 0.05f, 20.0f);
    float uvU = 8.0f, uvV = 8.0f;

    if (cfg.contains("scene"))
    {
        const json& sc = cfg["scene"];
        groundY = sc.value("ground_y", GROUND_Y);
        if (sc.contains("ground_scale") && sc["ground_scale"].is_array() &&
            sc["ground_scale"].size() == 3)
        {
            groundScale = glm::vec3(sc["ground_scale"][0],
                                    sc["ground_scale"][1],
                                    sc["ground_scale"][2]);
        }
        if (sc.contains("ground_uv") && sc["ground_uv"].is_array() &&
            sc["ground_uv"].size() == 2)
        {
            uvU = sc["ground_uv"][0];
            uvV = sc["ground_uv"][1];
        }
    }

    SetTransformations(groundScale, 0.0f, 0.0f, 0.0f,
                       glm::vec3(0.0f, groundY, 0.0f));
    SetShaderMaterial("groundMat");
    SetShaderTexture("ground");
    SetTextureUVScale(uvU, uvV);
    m_basicMeshes->DrawPlaneMesh();

    // ── All other scene geometry ──────────────────────────────────────
    BuildSceneFromConfig(cfg);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  RENDERING HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

/***********************************************************
 * RenderTower()
 * Constructs a tower from three primitives:
 *   1. Cylinder body (brick texture)
 *   2. Slightly wider cylinder ring as the battlement
 *   3. Cone roof seated on the battlement ring
 * Positional math documented inline so the seam-tightening
 * offsets are traceable without running the program.
 ***********************************************************/
void SceneManager::RenderTower(glm::vec3 position, glm::vec3 scale)
{
    // ── 1. Tower cylinder body ────────────────────────────────────────
    SetTransformations(scale, 0, 0, 0, position);
    SetShaderMaterial("turretMat");
    SetShaderTexture("tower");
    SetTextureUVScale(1.5f, 3.0f);
    m_basicMeshes->DrawCylinderMesh();

    // ── 2. Battlement ring ────────────────────────────────────────────
    float towerH        = scale.y;
    float battH         = 0.6f;    // ring half-height
    float battlementSink = -0.6f;  // slight downward shift to close seam

    glm::vec3 battScale(scale.x * 1.3f, battH, scale.z * 1.3f);
    glm::vec3 battPos(position.x,
                      position.y + towerH + battH + battlementSink,
                      position.z);

    SetTransformations(battScale, 0, 0, 0, battPos);
    SetShaderMaterial("turretMat");
    SetShaderTexture("battlement");
    SetTextureUVScale(0.8f, 0.6f);
    m_basicMeshes->DrawCylinderMesh();

    // ── 3. Cone roof ──────────────────────────────────────────────────
    // roofHalf is a negative offset that nests the cone apex into the
    // battlement ring, producing a tight visual joint.
    glm::vec3 roofScale(scale.x * 1.1f, towerH * 0.8f, scale.z * 1.1f);
    float     roofHalf = roofScale.y * -0.2f;

    glm::vec3 roofPos(position.x,
                      position.y + towerH + 2.0f * battH + roofHalf,
                      position.z);

    SetTransformations(roofScale, 0, 0, 0, roofPos);
    SetShaderMaterial("turretMat");
    SetShaderTexture("roof");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 * RenderFrontDoor()
 * Draws a textured plane flush with the front face of the
 * specified tower.  Extracted from RenderMainCastle() into
 * its own function to reduce method length and improve
 * testability.
 ***********************************************************/
void SceneManager::RenderFrontDoor(glm::vec3 tPos, glm::vec3 tScale)
{
    const float doorW = 0.5f;
    const float doorH = 1.6f;
    // push: offset along Z so the door plane sits on the cylinder surface
    const float push  = tScale.z * 1.0f;
    // doorY: centre of the door card in world Y
    const float doorY = tPos.y + 0.10f + doorH * 0.5f;

    SetTransformations(glm::vec3(doorW, doorH, 1.05f),
                       +90.0f, 0.0f, 0.0f,
                       glm::vec3(tPos.x, doorY, tPos.z + push));
    SetShaderMaterial("turretMat");
    SetShaderTexture("door");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 * DrawTopiaryBall()
 * Draws a sphere with the topiary texture at the given
 * world position and radius.  Factored out of the garden
 * lambda to allow independent use (e.g., spiral tops).
 ***********************************************************/
void SceneManager::DrawTopiaryBall(glm::vec3 pos, float r)
{
    SetTransformations(glm::vec3(r, r, r), 0, 0, 0, pos);
    SetShaderMaterial("turretMat");
    SetShaderTexture("topiary");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 * DrawTopiarySpiral()
 * Draws a stacked topiary form: a short cylinder trunk with
 * two foliage spheres of decreasing radius on top.
 * Base position is expressed as world X/Z; Y is derived
 * from GROUND_Y and trunk height so the base always sits
 * flush with the ground plane.
 ***********************************************************/
void SceneManager::DrawTopiarySpiral(glm::vec3 baseXZ)
{
    const float trunkH = 0.5f;   // cylinder height
    const float trunkR = 0.2f;   // cylinder radius
    const float r1     = 0.70f;  // lower sphere radius
    const float r2     = 0.55f;  // upper sphere radius
    const float gap    = -0.1f;  // negative gap = spheres overlap slightly

    // Trunk: base at GROUND_Y, centre at GROUND_Y + trunkH/2
    SetTransformations(glm::vec3(trunkR, trunkH, trunkR), 0.0f, 0.0f, 0.0f,
                       glm::vec3(baseXZ.x, GROUND_Y + trunkH * 0.6f - 0.2f, baseXZ.z));
    SetShaderMaterial("turretMat");
    SetShaderTexture("topiary");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Lower sphere: centre at trunk top + its own radius
    DrawTopiaryBall(glm::vec3(baseXZ.x,
                              GROUND_Y + trunkH + r1,
                              baseXZ.z), r1);

    // Upper sphere: rests on top of lower sphere (minus gap)
    DrawTopiaryBall(glm::vec3(baseXZ.x,
                              GROUND_Y + trunkH + r1 + gap + r1 + r2,
                              baseXZ.z), r2);
}

/***********************************************************
 * DrawLamp()
 * Renders a path lamp at world (x, z).  A cylinder pole is
 * drawn with base at GROUND_Y; a sphere globe sits on the
 * pole top.  Texture mode is explicitly restored after the
 * globe's flat-colour draw call.
 ***********************************************************/
void SceneManager::DrawLamp(float x, float z)
{
    const float poleH  = 2.8f;   // cylinder height
    const float poleR  = 0.08f;  // cylinder radius
    const float globeR = 0.35f;  // sphere radius

    // Pole
    SetTransformations(glm::vec3(poleR, poleH, poleR), 0, 0, 0,
                       glm::vec3(x, GROUND_Y + poleH * 0.0f, z));
    SetShaderMaterial("turretMat");
    SetShaderTexture("metal");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // Globe (flat warm colour – no texture)
    SetTransformations(glm::vec3(globeR, globeR, globeR), 0, 0, 0,
                       glm::vec3(x, GROUND_Y + poleH + globeR, z));
    SetShaderColor(1.0f, 0.95f, 0.85f, 1.0f);
    m_basicMeshes->DrawSphereMesh();

    // Re-enable texture sampling for subsequent draw calls.
    if (m_pShaderManager)
        m_pShaderManager->setIntValue(g_UseTextureName, true);
}
